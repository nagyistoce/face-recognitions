# -*- coding: utf-8 -*-
"""
Dieses Package Enthaelt alle relevanten haarcascade.xml Dateien um Redundanz zu vermeiden.
Import moeglich mit:

    import haarcascades
    assert(haarcascades.__file__)
    self.haarcascades_xml_path = os.path.split(haarcascades.__file__)[0]

"""